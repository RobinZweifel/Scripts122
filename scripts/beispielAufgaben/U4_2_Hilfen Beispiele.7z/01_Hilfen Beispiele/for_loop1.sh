#!/bin/bash
#
# for loop
for x in 1 2 3 4 5 # one two three four
do

	echo "number $x"
done

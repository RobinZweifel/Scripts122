#!/bin/bash
# Wir verwenden eine Variable
a="Hallo Leute"
echo "Die Variable a beinhaltet"
echo $a
b = "Guten Abend!"
echo "Die Variable b beinhaltet"
echo $b



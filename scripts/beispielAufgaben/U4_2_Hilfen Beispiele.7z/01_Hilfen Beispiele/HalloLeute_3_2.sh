#!/bin/bash
# Wir verwenden eine Variable
a="Hallo Leute"
b = "Guten Abend!"
echo "Die Variable a beinhaltet"
echo $a

echo "Die Variable b beinhaltet"
echo $b


#!/bin/bash
# Test
x=10
echo `expr $x + 1`
echo $(expr $x + 1)
echo $(($x + 1))


